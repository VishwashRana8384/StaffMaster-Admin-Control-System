Username : vansh
Password : 12345

StaffMaster – Admin Control System (ACS) is a Java-based employee management application designed to streamline and simplify employee data handling for organizations. The system is Admin-only, ensuring secure access and control over sensitive employee information.
With this system, the Admin can efficiently Add, Update, View, and Delete employee records, making management of staff details fast and organized.
